<footer class="bg-light text-center">
    <span class="text-center">&copy | OHRMS 2022</span>
</footer>

<script src="./assets/Js/index.js"></script>