<?php
session_start();

include '../../../assets/config/dbconfig.php';

$name = $_POST['name'];
$department = $_POST['department'];
$phoneNumber = $_POST['phoneNum'];
$email = $_POST['email'];
$gender = $_POST['gender'];
$password = $_POST['password'];
$address = $_POST['address'];
$salary = $_POST['salary'];

$sql = "select * from employee where emailAddress = '$email'";

$result = mysqli_query($con, $sql);
$num = mysqli_num_rows($result);

if ($num == 1) {
    $msg = "Email Already exist";
    header("Location: ../../add-employee?err=$msg");
    exit();
} else {
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $token = random_bytes(15);
    $token = bin2hex($token);

    $sql = "insert into employee (name, phoneNumber, department, emailAddress, password, address,gender,salary,token) values ('$name','$phoneNumber','$department','$email','$hashedPassword','$address','$gender','$salary','$token')";

    $result = mysqli_query($con, $sql);
    if ($result) {
        $subject = "Email Activation";
        $body = "Hi, $name. Click here to activate
        http://localhost/ohrm/activate?token=$token
        ";
        $headers = "From: management@ohrms.com";

        if (mail($email, $subject, $body, $headers)) {
            $msg = "Employee Added. Please check email for verification";
            header("Location: ../../employee?suc=$msg");
        } else {
            $msg = "Verification Failed";
            header("location: ../../employee?suc=$msg");
        }
    } else {
        $msg = "Employee Creation Failed";
        header("location: ../../add-employee?err=$msg");
    }
}
